class Juros(object):

    def __init__(self, vInicial, taxa, tempo):
        self.vInicial = vInicial
        self.taxa = taxa
        self.tempo = tempo
        self.vFinal = 0
        self.montante = 0


    def jurosSimples(Juros):
        Juros.vFinal = Juros.vInicial*(Juros.taxa/100) * Juros.tempo
        Juros.montante = Juros.vFinal + Juros.vInicial

        return Juros

    def jurosCompostos(Juros):
        Juros.montante = Juros.vInicial*(1+(Juros.taxa/100))**Juros.tempo

        return Juros
