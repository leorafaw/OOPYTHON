from oo_0410.Juros import *
import tkinter as tk
from tkinter import *

def calcular():
    valorInicial = float(vInicial.get())
    taxaA = float(taxa.get())
    periodoA = float(periodo.get())
    jurosA = Juros(valorInicial, taxaA, periodoA)
    tipo = v.get()

    if tipo == "simples":
        jurosA = Juros.jurosSimples(jurosA)
        txMontante['text'] = "Montante = {:.2f} ".format(jurosA.montante)

    if tipo == "composto":
        jurosA = Juros.jurosCompostos(jurosA)
        txMontante['text'] = "Montante = {:.2f} ".format(jurosA.montante)




janela1 = tk.Tk()
janela1.title("SIMULAÇÃO DE JUROS")
janela1["bg"] = "white"
janela1.geometry("260x270")

v = StringVar()
simples = Radiobutton(janela1, text="JUROS SIMPLES", value="simples", bg="white", variable=v)
simples.place(x=10, y=180)
v.set("simples")

compostos = Radiobutton(janela1, text="JUROS COMPOSTOS", value="composto", bg="white", variable=v)
compostos.place(x=120, y=180)

tx = Label(janela1, text="Capital Inicial:", font=("Arial", 10), bg="white")
tx.place(x=8, y=10)
vInicial = Entry(janela1, width=40)
vInicial.place(x=7, y=30)

tx2 = Label(janela1, text="Taxa de Juros ao Mês:", font=("Arial", 10), bg="white")
tx2.place(x=8, y=70)
taxa = Entry(janela1, width=40)
taxa.place(x=7, y=90)

tx3 = Label(janela1, text="Periodos em Meses:", font=("Arial", 10), bg="white")
tx3.place(x=8, y=130)
periodo = Entry(janela1, width=40)
periodo.place(x=7, y=150)

btCalc = Button(janela1, width=10, text="Calcular", bg="white", command=calcular)
btCalc.place(x=90, y=215)

txMontante = Label(janela1, text="", font=("Arial", 10), bg="white")
txMontante.place(x=77, y=248)

janela1.mainloop()
